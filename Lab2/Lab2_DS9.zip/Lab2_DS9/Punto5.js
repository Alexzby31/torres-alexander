// Declarar una variable tipo objeto y asignarle valores
let miObjeto = {
    numero: 42,
    cadena: "Hola",
    booleano: true,
    objetoVacio: {}
};

// Imprimir el objeto en la consola
console.log(miObjeto);
