// Declarar dos variables utilizando la palabra reservada "const"
const variable1 = 10;
const variable2 = "Hola";

// Imprimir el tipo de dato de las variables
console.log(typeof variable1);
console.log(typeof variable2);
