// Declarar dos variables utilizando la palabra reservada "let"
let variable1 = "Hola";
let variable2 = "mundo";

// Concatenar las variables
let concatenacion = variable1 + " " + variable2;

// Imprimir la concatenación en la consola
console.log(concatenacion);
